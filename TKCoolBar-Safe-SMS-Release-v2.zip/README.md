# TK Cool Bar — Safe SMS Release v2

This version does NOT request SEND_SMS, READ_SMS, RECEIVE_SMS, or CALL_PHONE.
It opens the phone SMS app with the invoice text pre-filled using Android ACTION_SENDTO + smsto.

Important: the SMS sender number is controlled by the SIM/network. The app cannot spoof a sender number.

The GitHub Actions workflow builds a release APK, checks the APK permissions, signs it, verifies the signature, and uploads the APK as an artifact.
