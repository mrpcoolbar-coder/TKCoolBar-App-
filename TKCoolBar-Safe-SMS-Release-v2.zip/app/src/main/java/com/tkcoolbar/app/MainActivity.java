package com.tkcoolbar.app;

import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Build;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.*;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    DB db;
    LinearLayout root, content;
    TextView title;
    final int RED=Color.rgb(198,40,40);

    static class Product { long id; String name; double price; Product(long i,String n,double p){id=i;name=n;price=p;} }
    static class PurchaseLine { Spinner spinner; EditText qty; TextView price,total; Button remove; }

    int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    TextView tv(String s,int sp){TextView t=new TextView(this);t.setText(s);t.setTextSize(sp);t.setTextColor(Color.rgb(32,33,36));t.setPadding(dp(12),dp(8),dp(12),dp(8));return t;}
    Button btn(String s){Button b=new Button(this);b.setText(s);return b;}
    EditText edit(String hint){EditText e=new EditText(this);e.setHint(hint);e.setTextSize(16);return e;}
    LinearLayout box(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(dp(8),0,dp(8),0);return l;}

    @Override public void onCreate(Bundle b){super.onCreate(b);db=new DB(this);build();home();}

    void build(){
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(Color.rgb(247,247,247));
        LinearLayout bar=new LinearLayout(this);bar.setGravity(Gravity.CENTER_VERTICAL);bar.setPadding(dp(8),dp(4),dp(8),dp(4));bar.setBackgroundColor(RED);
        title=tv("TK COOL BAR",20);title.setTextColor(Color.WHITE);title.setTypeface(null,1);bar.addView(title,new LinearLayout.LayoutParams(0,dp(56),1));
        ImageView logo=new ImageView(this); logo.setImageResource(com.tkcoolbar.app.R.raw.tk_cool_bar_logo); logo.setAdjustViewBounds(true); logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE); bar.addView(logo,new LinearLayout.LayoutParams(dp(56),dp(56))); Button menu=btn("☰");menu.setOnClickListener(v->menu());bar.addView(menu,new LinearLayout.LayoutParams(dp(64),dp(56)));root.addView(bar);
        content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);ScrollView sv=new ScrollView(this);sv.addView(content);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);
    }
    void clear(String s){content.removeAllViews();title.setText(s);}
    String money(double x){return String.format(Locale.US,"%.2f",x);}
    String date(long t){return new SimpleDateFormat("dd-MM-yyyy, hh:mm a",Locale.getDefault()).format(new Date(t));}

    void home(){
        clear("TK COOL BAR");
        content.addView(tv("✨ Welcome to TK Cool Bar ✨",22));
        content.addView(tv("Today Sales     ₹"+money(db.todaySales()),19));
        content.addView(tv("Today Advance   ₹"+money(db.todayAdvance()),19));
        content.addView(tv("Customers       "+db.customerCount(),19));
        content.addView(tv("Total Balance   ₹"+money(db.totalBalance()),19));
        Button c=btn("👥  Customers");c.setOnClickListener(v->customers());content.addView(c);
        Button a=btn("💰  Add Advance");a.setOnClickListener(v->advance());content.addView(a);
        Button p=btn("🧾  New Purchase");p.setOnClickListener(v->purchase());content.addView(p);
        Button pc=btn("🍹  Item Prices / Products");pc.setOnClickListener(v->productsScreen());content.addView(pc);
        Button h=btn("📋  Transaction History");h.setOnClickListener(v->history());content.addView(h);
        Button s=btn("⚙  Schemes / Settings");s.setOnClickListener(v->schemes());content.addView(s);
    }

    void customers(){
        clear("CUSTOMERS");
        EditText search=edit("🔎 Search by customer name or mobile number");content.addView(search);
        Button add=btn("＋ Add Customer");add.setOnClickListener(v->addCustomer());content.addView(add);
        LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);content.addView(list);
        Runnable refresh=()->{
            list.removeAllViews(); String q=search.getText().toString().trim(); Cursor c=q.isEmpty()?db.customers():db.searchCustomers(q);
            while(c.moveToNext()){long id=c.getLong(0);String name=c.getString(1),phone=c.getString(2);Button b=btn(name+"  •  "+phone+"  •  ₹"+money(db.balance(id)));b.setOnClickListener(v->customer(id));list.addView(b);}c.close();
        };
        search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int b,int c){}public void onTextChanged(CharSequence s,int a,int b,int c){refresh.run();}public void afterTextChanged(Editable e){}});
        refresh.run();
        Button back=btn("← Dashboard");back.setOnClickListener(v->home());content.addView(back);
    }

    void addCustomer(){
        LinearLayout l=box();EditText n=edit("Customer name");EditText p=edit("Mobile number");p.setInputType(2);l.addView(n);l.addView(p);
        new AlertDialog.Builder(this).setTitle("Add Customer").setView(l).setPositiveButton("Save",(d,w)->{if(n.getText().toString().trim().length()>0){db.addCustomer(n.getText().toString().trim(),p.getText().toString().trim());customers();}}).setNegativeButton("Cancel",null).show();
    }

    void customer(long id){
        Cursor c=db.customer(id);if(!c.moveToFirst()){c.close();return;}String name=c.getString(1),phone=c.getString(2);c.close();clear(name);
        content.addView(tv("📱 "+phone+"\n💰 Remaining balance: ₹"+money(db.balance(id)),19));
        Button a=btn("＋ Advance");a.setOnClickListener(v->advanceFor(id,name,phone));content.addView(a);
        Button p=btn("🧾 New Purchase");p.setOnClickListener(v->purchaseFor(id,name,phone));content.addView(p);
        Button h=btn("📋 History");h.setOnClickListener(v->customerHistory(id));content.addView(h);
        Button m=btn("📩 Send Balance SMS");m.setOnClickListener(v->sendSms(phone,invoiceHeader(name)+"\nCurrent balance: ₹"+money(db.balance(id))+"\n\n✨ Thank you for visiting TK Cool Bar! ✨"));content.addView(m);
        Button back=btn("← Customers");back.setOnClickListener(v->customers());content.addView(back);
    }

    void advance(){chooseCustomer(true);}
    void purchase(){chooseCustomer(false);}
    void chooseCustomer(boolean adv){
        Cursor c=db.customers();final ArrayList<Long> ids=new ArrayList<>();final ArrayList<String> names=new ArrayList<>();
        while(c.moveToNext()){ids.add(c.getLong(0));names.add(c.getString(1)+" • "+c.getString(2));}c.close();
        if(names.isEmpty()){new AlertDialog.Builder(this).setMessage("Add a customer first.").setPositiveButton("Add",(d,w)->addCustomer()).setNegativeButton("Cancel",null).show();return;}
        new AlertDialog.Builder(this).setTitle(adv?"Select customer for advance":"Select customer for purchase").setItems(names.toArray(new String[0]),(d,w)->{Cursor x=db.customer(ids.get(w));x.moveToFirst();String n=x.getString(1),p=x.getString(2);x.close();if(adv)advanceFor(ids.get(w),n,p);else purchaseFor(ids.get(w),n,p);}).show();
    }

    void advanceFor(long id,String name,String phone){
        LinearLayout l=box();EditText e=edit("Paid amount (e.g. 1000)");e.setInputType(2|8192);l.addView(e);l.addView(tv("Scheme: ₹500→₹550, ₹1000→₹1100, ₹2000→₹2300",15));
        new AlertDialog.Builder(this).setTitle("Advance - "+name).setView(l).setPositiveButton("Save",(d,w)->{double paid=num(e);double value=schemeValue(paid);if(paid<=0){return;}db.addTx(id,"ADVANCE",value,"Paid ₹"+money(paid)+"; shopping value ₹"+money(value));String body=invoiceHeader(name)+"\n\nADVANCE RECEIVED\nPaid Amount: ₹"+money(paid)+"\nShopping Value Added: ₹"+money(value)+"\nNew Remaining Balance: ₹"+money(db.balance(id))+"\n\n✨ Thank you for visiting TK Cool Bar! ✨\nWe truly appreciate your support. ❤️";sendSms(phone,body);customer(id);}).setNegativeButton("Cancel",null).show();
    }
    double schemeValue(double p){Cursor c=db.schemes();double v=p;while(c.moveToNext()){if(Math.abs(c.getDouble(1)-p)<.01){v=c.getDouble(2);break;}}c.close();return v;}
    double num(EditText e){try{return Double.parseDouble(e.getText().toString().trim());}catch(Exception x){return 0;}}

    ArrayList<Product> loadProducts(){ArrayList<Product> a=new ArrayList<>();Cursor c=db.products();while(c.moveToNext())a.add(new Product(c.getLong(0),c.getString(1),c.getDouble(2)));c.close();return a;}

    void purchaseFor(long id,String name,String phone){
        final ArrayList<Product> products=loadProducts();
        final ArrayList<PurchaseLine> lines=new ArrayList<>();
        LinearLayout outer=box();
        TextView balance=tv("Prepaid Amount: ₹"+money(db.balance(id)),18);balance.setTypeface(null,1);outer.addView(balance);
        TextView totalView=tv("Invoice Total: ₹0.00",20);totalView.setTypeface(null,1);outer.addView(totalView);
        LinearLayout rows=new LinearLayout(this);rows.setOrientation(LinearLayout.VERTICAL);outer.addView(rows);
        Button add=btn("＋ Add Item");outer.addView(add);
        TextView note=tv("Select an item from the shop price list. The price is filled automatically.",14);outer.addView(note);
        Runnable update=()->{double total=0;for(PurchaseLine line:lines){int q=qty(line);Product p=(Product)line.spinner.getSelectedItem();if(p!=null){double x=q*p.price;line.price.setText("₹"+money(p.price));line.total.setText("Total ₹"+money(x));total+=x;}}totalView.setText("Invoice Total: ₹"+money(total));};
        Runnable addRow=()->{
            PurchaseLine line=new PurchaseLine();
            LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.VERTICAL);row.setPadding(0,dp(6),0,dp(6));
            line.spinner=new Spinner(this);ArrayAdapter<Product> ad=new ArrayAdapter<Product>(this,android.R.layout.simple_spinner_dropdown_item,products){@Override public View getView(int position,View convertView,android.view.ViewGroup parent){TextView t=(TextView)super.getView(position,convertView,parent);t.setText(products.get(position).name+"  ₹"+money(products.get(position).price));return t;}};line.spinner.setAdapter(ad);
            LinearLayout sub=new LinearLayout(this);sub.setGravity(Gravity.CENTER_VERTICAL);line.qty=edit("Qty");line.qty.setInputType(2);line.qty.setText("1");line.price=tv("₹0.00",16);line.total=tv("Total ₹0.00",16);line.remove=btn("✕");
            sub.addView(line.qty,new LinearLayout.LayoutParams(dp(70),dp(52)));sub.addView(line.price,new LinearLayout.LayoutParams(dp(90),dp(52)));sub.addView(line.total,new LinearLayout.LayoutParams(0,dp(52),1));sub.addView(line.remove,new LinearLayout.LayoutParams(dp(60),dp(52)));
            row.addView(line.spinner);row.addView(sub);rows.addView(row);lines.add(line);
            line.spinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> p){}public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long x){update.run();}});
            line.qty.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int b,int c){}public void onTextChanged(CharSequence s,int a,int b,int c){update.run();}public void afterTextChanged(Editable e){}});
            line.remove.setOnClickListener(v->{lines.remove(line);rows.removeView(row);update.run();});update.run();
        };
        add.setOnClickListener(v->addRow.run());addRow.run();
        ScrollView sc=new ScrollView(this);sc.addView(outer);
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("🧾 Invoice - "+name).setView(sc).setPositiveButton("Save + Send SMS",null).setNegativeButton("Cancel",null).create();
        dialog.setOnShowListener(x->{dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
            double total=0;StringBuilder items=new StringBuilder();
            if(lines.isEmpty()){Toast.makeText(this,"Tap + Add Item",Toast.LENGTH_LONG).show();return;}
            for(PurchaseLine line:lines){Product p=(Product)line.spinner.getSelectedItem();int q=qty(line);if(p==null||q<=0){Toast.makeText(this,"Check item quantity",Toast.LENGTH_LONG).show();return;}double rowTotal=q*p.price;total+=rowTotal;items.append("• ").append(p.name).append("  ").append(q).append(" × ₹").append(money(p.price)).append(" = ₹").append(money(rowTotal)).append("\n");}
            double before=db.balance(id);if(total<=0||total>before){Toast.makeText(this,"Insufficient prepaid balance",Toast.LENGTH_LONG).show();return;}
            long txId=db.addTx(id,"PURCHASE",total,"Invoice purchase - "+lines.size()+" item(s)");
            for(PurchaseLine line:lines){Product p=(Product)line.spinner.getSelectedItem();int q=qty(line);db.addTxItem(txId,p.id,p.name,q,p.price,q*p.price);}
            double after=db.balance(id);
            String body=invoiceHeader(name)+"\n\n🧾 PURCHASE INVOICE\n\n"+items+"\nTOTAL: ₹"+money(total)+"\nPrepaid Amount: ₹"+money(before)+"\nRemaining Amount: ₹"+money(after)+"\n\n✨ Thank you for visiting TK Cool Bar! ✨\nWe truly appreciate your support. ❤️\nPlease visit us again!";
            dialog.dismiss();sendSms(phone,body);customer(id);
        });});dialog.show();
    }
    int qty(PurchaseLine l){try{return Integer.parseInt(l.qty.getText().toString().trim());}catch(Exception e){return 0;}}

    String invoiceHeader(String name){return "✨ TK COOL BAR ✨\nCustomer: "+name+"\nDate & Time: "+date(System.currentTimeMillis());}

    void sendSms(String phone,String body){
        if(phone==null||phone.trim().isEmpty()){Toast.makeText(this,"Customer mobile number is missing",Toast.LENGTH_LONG).show();return;}
        String n=phone.replaceAll("[^0-9]","");
        if(n.startsWith("91")&&n.length()==12)n=n.substring(2);
        if(n.length()!=10){Toast.makeText(this,"Enter a valid 10-digit mobile number",Toast.LENGTH_LONG).show();return;}
        try{
            Intent intent=new Intent(Intent.ACTION_SENDTO);
            intent.setData(android.net.Uri.parse("smsto:"+n));
            intent.putExtra("sms_body",body);
            startActivity(intent);
        }catch(Exception e){Toast.makeText(this,"No SMS app is available on this phone",Toast.LENGTH_LONG).show();}
    }

    void productsScreen(){
        clear("ITEM PRICES");
        content.addView(tv("🏷️ Shop price list — these prices are used automatically in invoices.",16));
        Button add=btn("＋ Add New Item");add.setOnClickListener(v->addProduct());content.addView(add);
        Cursor c=db.products();while(c.moveToNext()){long id=c.getLong(0);String name=c.getString(1);double price=c.getDouble(2);Button b=btn(name+"   ₹"+money(price));b.setOnClickListener(v->editProduct(id));content.addView(b);}c.close();
        Button back=btn("← Dashboard");back.setOnClickListener(v->home());content.addView(back);
    }
    void addProduct(){LinearLayout l=box();EditText n=edit("Item name");EditText p=edit("Price");p.setInputType(2|8192);l.addView(n);l.addView(p);new AlertDialog.Builder(this).setTitle("Add Item + Price").setView(l).setPositiveButton("Save",(d,w)->{if(!n.getText().toString().trim().isEmpty()&&num(p)>0){db.addProduct(n.getText().toString().trim(),num(p));productsScreen();}}).setNegativeButton("Cancel",null).show();}
    void editProduct(long id){Cursor c=db.product(id);if(!c.moveToFirst()){c.close();return;}String oldName=c.getString(1);double oldPrice=c.getDouble(2);c.close();LinearLayout l=box();EditText n=edit("Item name");n.setText(oldName);EditText p=edit("Price");p.setInputType(2|8192);p.setText(money(oldPrice));l.addView(n);l.addView(p);new AlertDialog.Builder(this).setTitle("Edit Item Price").setView(l).setPositiveButton("Update",(d,w)->{if(!n.getText().toString().trim().isEmpty()&&num(p)>0){db.updateProduct(id,n.getText().toString().trim(),num(p));productsScreen();}}).setNegativeButton("Cancel",null).show();}

    void customerHistory(long id){clear("TRANSACTIONS");Cursor c=db.txs(id);while(c.moveToNext()){long txId=c.getLong(0);String type=c.getString(1);double a=c.getDouble(2);String note=c.getString(3);long tm=c.getLong(4);content.addView(tv(date(tm)+"\n"+type+"  ₹"+money(a)+"\n"+note,16));if("PURCHASE".equals(type)){Cursor it=db.txItems(txId);while(it.moveToNext())content.addView(tv("  • "+it.getString(0)+"  "+it.getInt(1)+" × ₹"+money(it.getDouble(2))+" = ₹"+money(it.getDouble(3)),14));it.close();}}c.close();Button b=btn("← Customer");b.setOnClickListener(v->customer(id));content.addView(b);}
    void history(){clear("TRANSACTION HISTORY");Cursor c=db.allTx();while(c.moveToNext())content.addView(tv(date(c.getLong(4))+"\n"+c.getString(0)+" • "+c.getString(1)+" • ₹"+money(c.getDouble(2))+"\n"+c.getString(3),15));c.close();Button b=btn("← Dashboard");b.setOnClickListener(v->home());content.addView(b);}
    void schemes(){clear("SCHEMES");Cursor c=db.schemes();while(c.moveToNext()){long id=c.getLong(0);TextView t=tv("₹"+money(c.getDouble(1))+" → ₹"+money(c.getDouble(2)),18);content.addView(t);Button del=btn("Delete");del.setOnClickListener(v->{db.deleteScheme(id);schemes();});content.addView(del);}c.close();Button add=btn("＋ Add Scheme");add.setOnClickListener(v->addScheme());content.addView(add);Button b=btn("← Dashboard");b.setOnClickListener(v->home());content.addView(b);}
    void addScheme(){LinearLayout l=box();EditText p=edit("Paid amount");p.setInputType(2|8192);EditText v=edit("Shopping value");v.setInputType(2|8192);l.addView(p);l.addView(v);new AlertDialog.Builder(this).setTitle("New Scheme").setView(l).setPositiveButton("Save",(d,w)->{if(num(p)>0&&num(v)>0)db.addScheme(num(p),num(v));schemes();}).setNegativeButton("Cancel",null).show();}
    void menu(){new AlertDialog.Builder(this).setTitle("TK Cool Bar").setItems(new String[]{"Dashboard","Customers","Item Prices / Products","Transaction History","Schemes / Settings"},(d,w)->{if(w==0)home();if(w==1)customers();if(w==2)productsScreen();if(w==3)history();if(w==4)schemes();}).show();}
    @Override public void onBackPressed(){home();}
}
