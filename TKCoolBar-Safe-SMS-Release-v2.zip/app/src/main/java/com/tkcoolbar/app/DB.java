package com.tkcoolbar.app;

import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;

public class DB extends SQLiteOpenHelper {
    public DB(Context c){ super(c,"tkcoolbar.db",null,2); }
    public void onCreate(SQLiteDatabase d){
        d.execSQL("CREATE TABLE customers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,phone TEXT,created INTEGER)");
        d.execSQL("CREATE TABLE tx(id INTEGER PRIMARY KEY AUTOINCREMENT,customer_id INTEGER,type TEXT,amount REAL,note TEXT,created INTEGER)");
        d.execSQL("CREATE TABLE schemes(id INTEGER PRIMARY KEY AUTOINCREMENT,pay REAL,value REAL)");
        d.execSQL("CREATE TABLE products(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL UNIQUE,price REAL NOT NULL,active INTEGER DEFAULT 1)");
        d.execSQL("CREATE TABLE tx_items(id INTEGER PRIMARY KEY AUTOINCREMENT,tx_id INTEGER,product_id INTEGER,name TEXT,qty INTEGER,unit_price REAL,total REAL)");
        seedSchemes(d);
        seedProducts(d);
    }
    void seedSchemes(SQLiteDatabase d){d.execSQL("INSERT INTO schemes(pay,value) VALUES(500,550),(1000,1100),(2000,2300)");}
    void seedProducts(SQLiteDatabase d){
        String[][] p={
            {"Tea","15"},{"Ginger Tea","20"},{"Cardamom Tea","20"},{"Masala Tea","20"},{"Lemon Tea","20"},{"Black Tea","15"},{"Green Tea","20"},{"Honey Lemon Tea","25"},
            {"Filter Coffee","25"},{"Regular Coffee","20"},{"Black Coffee","20"},{"Cold Coffee","50"},{"Ginger Coffee","25"},{"Cardamom Coffee","25"},{"Sukku Coffee","25"},
            {"Milk","20"},{"Hot Badam Milk","40"},{"Chocolate Milk","40"},{"Horlicks","40"},{"Boost","40"},{"Ragi Malt","40"},
            {"Vanilla Milkshake","70"},{"Chocolate Milkshake","80"},{"Strawberry Milkshake","80"},{"Mango Milkshake","80"},{"Banana Milkshake","70"},{"Brownie Milkshake","100"},{"Peanut Butter Milkshake","100"},{"Dry Fruit Milkshake","110"},{"Dates Milkshake","100"},{"Mixed Fruit Milkshake","90"},
            {"Fresh Lime Juice","30"},{"Orange Juice","50"},{"Mosambi Juice","50"},{"Watermelon Juice","40"},{"Pineapple Juice","50"},{"Grape Juice","50"},
            {"Pani Puri","40"},{"Bhel Puri","50"},{"Samosa Chaat","50"},{"Medhu Vada","20"},{"Onion Bonda","15"},{"Paruppu Vada","15"},{"Bun Butter Jam","30"},
            {"Top Ramen Noodles","50"},{"Chicken Maggi","80"},{"Paneer Maggi","70"},{"Chicken Sandwich","90"},{"Chicken Cheese Sandwich","110"},{"Chicken Nuggets","90"},{"Chicken Samosa","35"},{"Paneer Sandwich","80"}
        };
        for(String[] x:p){ContentValues v=new ContentValues();v.put("name",x[0]);v.put("price",Double.parseDouble(x[1]));v.put("active",1);d.insertWithOnConflict("products",null,v,SQLiteDatabase.CONFLICT_IGNORE);}
    }
    public void onUpgrade(SQLiteDatabase d,int oldV,int newV){
        if(oldV<2){
            d.execSQL("CREATE TABLE IF NOT EXISTS products(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL UNIQUE,price REAL NOT NULL,active INTEGER DEFAULT 1)");
            d.execSQL("CREATE TABLE IF NOT EXISTS tx_items(id INTEGER PRIMARY KEY AUTOINCREMENT,tx_id INTEGER,product_id INTEGER,name TEXT,qty INTEGER,unit_price REAL,total REAL)");
            seedProducts(d);
        }
    }
    public long addCustomer(String n,String p){ContentValues v=new ContentValues();v.put("name",n);v.put("phone",p);v.put("created",System.currentTimeMillis());return getWritableDatabase().insert("customers",null,v);}
    public Cursor customers(){return getReadableDatabase().rawQuery("SELECT id,name,phone FROM customers ORDER BY name",null);}
    public Cursor searchCustomers(String q){String s="%"+q+"%";return getReadableDatabase().rawQuery("SELECT id,name,phone FROM customers WHERE name LIKE ? OR phone LIKE ? ORDER BY name",new String[]{s,s});}
    public Cursor customer(long id){return getReadableDatabase().rawQuery("SELECT id,name,phone FROM customers WHERE id=?",new String[]{""+id});}
    public long addTx(long cid,String type,double amt,String note){ContentValues v=new ContentValues();v.put("customer_id",cid);v.put("type",type);v.put("amount",amt);v.put("note",note);v.put("created",System.currentTimeMillis());return getWritableDatabase().insert("tx",null,v);}
    public void addTxItem(long txId,long productId,String name,int qty,double unit,double total){ContentValues v=new ContentValues();v.put("tx_id",txId);v.put("product_id",productId);v.put("name",name);v.put("qty",qty);v.put("unit_price",unit);v.put("total",total);getWritableDatabase().insert("tx_items",null,v);}
    public Cursor products(){return getReadableDatabase().rawQuery("SELECT id,name,price FROM products WHERE active=1 ORDER BY name",null);}
    public Cursor product(long id){return getReadableDatabase().rawQuery("SELECT id,name,price FROM products WHERE id=?",new String[]{""+id});}
    public void updateProduct(long id,String name,double price){ContentValues v=new ContentValues();v.put("name",name);v.put("price",price);getWritableDatabase().update("products",v,"id=?",new String[]{""+id});}
    public long addProduct(String name,double price){ContentValues v=new ContentValues();v.put("name",name);v.put("price",price);v.put("active",1);return getWritableDatabase().insertWithOnConflict("products",null,v,SQLiteDatabase.CONFLICT_REPLACE);}
    public Cursor txItems(long txId){return getReadableDatabase().rawQuery("SELECT name,qty,unit_price,total FROM tx_items WHERE tx_id=? ORDER BY id",new String[]{""+txId});}
    public double balance(long cid){Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(CASE WHEN type='ADVANCE' THEN amount ELSE 0 END),0)-COALESCE(SUM(CASE WHEN type='PURCHASE' THEN amount ELSE 0 END),0) FROM tx WHERE customer_id=?",new String[]{""+cid});double x=0;if(c.moveToFirst())x=c.getDouble(0);c.close();return x;}
    public double todaySales(){Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(amount),0) FROM tx WHERE type='PURCHASE' AND date(created/1000,'unixepoch','localtime')=date('now','localtime')",null);double x=0;if(c.moveToFirst())x=c.getDouble(0);c.close();return x;}
    public double todayAdvance(){Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(amount),0) FROM tx WHERE type='ADVANCE' AND date(created/1000,'unixepoch','localtime')=date('now','localtime')",null);double x=0;if(c.moveToFirst())x=c.getDouble(0);c.close();return x;}
    public int customerCount(){Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM customers",null);int x=0;if(c.moveToFirst())x=c.getInt(0);c.close();return x;}
    public double totalBalance(){Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(CASE WHEN type='ADVANCE' THEN amount ELSE -amount END),0) FROM tx",null);double x=0;if(c.moveToFirst())x=c.getDouble(0);c.close();return x;}
    public Cursor txs(long cid){return getReadableDatabase().rawQuery("SELECT id,type,amount,note,created FROM tx WHERE customer_id=? ORDER BY created DESC",new String[]{""+cid});}
    public Cursor allTx(){return getReadableDatabase().rawQuery("SELECT c.name,t.type,t.amount,t.note,t.created FROM tx t JOIN customers c ON c.id=t.customer_id ORDER BY t.created DESC LIMIT 100",null);}
    public Cursor schemes(){return getReadableDatabase().rawQuery("SELECT id,pay,value FROM schemes ORDER BY pay",null);}
    public void addScheme(double p,double v){ContentValues x=new ContentValues();x.put("pay",p);x.put("value",v);getWritableDatabase().insert("schemes",null,x);}
    public void deleteScheme(long id){getWritableDatabase().delete("schemes","id=?",new String[]{""+id});}
}
